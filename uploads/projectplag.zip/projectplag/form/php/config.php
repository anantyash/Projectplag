<?php 
 
 $con = mysqli_connect("localhost","root","","projectplag_db") or die("Couldn't connect");

?>