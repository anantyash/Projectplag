<?php 
   session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="logincss.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <title>Login</title>
</head>
<body>
  <div class="wrapper">

  <?php 
             
    include("php/config.php");
    if(isset($_POST['submit'])){
      $email = mysqli_real_escape_string($con,$_POST['email']);
      $password = mysqli_real_escape_string($con,$_POST['password']);

      $result = mysqli_query($con,"SELECT * FROM form_detail WHERE Email='$email' AND Password='$password' ") or die("Select Error");
      $row = mysqli_fetch_assoc($result);

      if(is_array($row) && !empty($row)){
            $_SESSION['valid'] = $row['Email'];
            $_SESSION['username'] = $row['Username'];
            $_SESSION['password'] = $row['Password'];
            $_SESSION['id'] = $row['Id'];
      }
      else{
            echo "<div class='message'>
                  <p>Wrong Username or Password</p>
                  </div> <br>";
            echo "<a href='loginphp.php'><button class='btn'>Go Back</button>";
        
      }
      if(isset($_SESSION['valid'])){
                   header("Location: loginphp.php");
               }
       }else{
    ?>
      
    <header>Login Form</header>
    <form action="dashboardhtml.html">
      <div class="field email">
        <div class="input-area">
          <input type="text" placeholder="Email Address">
          <i class="icon fas fa-envelope"></i>
          <i class="error error-icon fas fa-exclamation-circle"></i>
        </div>
        <div class="error error-txt">Email can't be blank</div>
      </div>
      <div class="field password">
        <div class="input-area">
          <input type="password" placeholder="Password">
          <i class="icon fas fa-lock"></i>
          <i class="error error-icon fas fa-exclamation-circle"></i>
        </div>
        <div class="error error-txt">Password can't be blank</div>
      </div>
      <div class="pass-txt"><a href="#" " >Forgot password?</a></div>
      <input type="submit" value="Login">
    </form>
    <div class="sign-txt">Not yet member? <a href="registerhtml.php">Signup now</a></div>
  
    <?php } ?>
  </div>

  <script src="loginjs.js"></script>

</body>
</html>
