<?php 
 
//  $con = mysqli_connect("localhost","root","","projectplag_db") or die("Couldn't connect");

$sname = "localhost";
$uname = "root";
$password = "";

$db_name = "projectplag_db";

$con = mysqli_connect($sname, $uname, $password, $db_name);

if (!$con) {
	echo "Connection failed!";
	exit();
}

?>